
from database.admin_db import AdminDB
db = AdminDB()
db.create_user('test', 'test', 'lososs@email.cz')
exit()